
//Codes corresponding to different tokens

#define PROGRAM_code 1
#define VAR_code 2
#define BEGIN_code 3
#define END_code 4
#define ENDPERIOD_code 5
#define INTEGER_KEYWORD_code 6
#define FOR_code 7
#define READ_code 8
#define WRITE_code 9
#define TO_code 10
#define DO_code 11
#define SEMICOLON_code 12
#define COLON_code 13
#define COMMA_code 14
#define ASSIGNMENT_code 15
#define PLUS_code 16
#define MINUS_code 17
#define MULTIPLY_code 18
#define DIVIDE_code 19
#define LEFTPARENTHESIS_code 20
#define RIGHTPARENTHESIS_code 21
#define IDENTIFIER_code 22
#define INTEGER_code 23